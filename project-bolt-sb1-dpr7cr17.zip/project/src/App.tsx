import React from 'react';
import { Globe2 } from 'lucide-react';
import MapView from './components/Map';
import ProjectSection from './components/ProjectSection';
import { projects } from './data/projects';

function App() {
  const scrollToProject = (projectId: string) => {
    const element = document.getElementById(projectId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative">
      {/* Hero Section */}
      <section className="h-screen relative flex items-center justify-center">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1493246507139-91e8fad9978e"
            alt="Rural European landscape"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-50" />
        </div>
        
        <div className="relative text-center text-white px-4">
          <Globe2 className="w-16 h-16 mx-auto mb-6" />
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Stories from Rural Europe</h1>
          <p className="text-xl md:text-2xl max-w-2xl mx-auto mb-8">
            Documenting the rich cultural heritage and culinary traditions across European communities
          </p>
        </div>
      </section>

      {/* Map Section */}
      <section className="h-screen sticky top-0">
        <MapView projects={projects} onProjectSelect={scrollToProject} />
      </section>

      {/* Project Sections */}
      {projects.map((project, index) => (
        <ProjectSection 
          key={project.id} 
          project={project}
          isLast={index === projects.length - 1}
        />
      ))}
    </div>
  );
}

export default App;