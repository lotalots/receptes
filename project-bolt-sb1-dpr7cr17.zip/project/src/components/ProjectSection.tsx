import React from 'react';
import { useInView } from 'react-intersection-observer';
import { Project } from '../types';

interface ProjectSectionProps {
  project: Project;
  isLast: boolean;
}

export default function ProjectSection({ project, isLast }: ProjectSectionProps) {
  // Title strip observer
  const { ref: titleRef, inView: titleInView } = useInView({
    threshold: 0.5,
    triggerOnce: false
  });

  // First slide (text) observer
  const { ref: firstSlideRef, inView: firstSlideInView } = useInView({
    threshold: 0.3,
    triggerOnce: false
  });

  // Second slide (images) observer
  const { ref: secondSlideRef, inView: secondSlideInView } = useInView({
    threshold: 0.3,
    triggerOnce: false
  });

  // Third slide (video) observer
  const { ref: thirdSlideRef, inView: thirdSlideInView } = useInView({
    threshold: 0.3,
    triggerOnce: false
  });

  // Summary slide observer
  const { ref: summaryRef, inView: summaryInView } = useInView({
    threshold: 0.3,
    triggerOnce: false
  });

  const getTextPositionClasses = () => {
    switch (project.textPosition) {
      case 'left':
        return 'ml-8 md:ml-12';
      case 'right':
        return 'mr-8 md:mr-12 ml-auto';
      default:
        return 'mx-auto';
    }
  };

  const getSlideTransform = (inView: boolean, index: number) => {
    if (project.transitionType === 'horizontal' && index === 0) {
      return inView ? 'translate-x-0' : 'translate-x-full';
    }
    return inView ? 'translate-y-0' : 'translate-y-[100vh]';
  };

  const getBackgroundTransform = (inView: boolean, index: number) => {
    if (project.transitionType === 'horizontal' && index === 0) {
      return inView ? 'translate-x-0 scale-110' : 'translate-x-[-100%] scale-110';
    }
    return `scale-${inView ? '120' : '110'}`;
  };

  return (
    <>
      {/* Project Title Strip */}
      <section
        ref={titleRef}
        className="h-[50vh] relative bg-black flex items-center justify-center overflow-hidden"
      >
        <div 
          className={`text-center transform transition-all duration-1000 ${
            titleInView ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'
          }`}
        >
          <h2 className="text-7xl font-bold text-white tracking-wider mb-6">{project.title}</h2>
          <p className="text-3xl text-gray-400">{project.location}</p>
        </div>
      </section>

      {/* First Slide - Text */}
      <section
        id={`${project.id}-1`}
        ref={firstSlideRef}
        className="relative h-[200vh] w-full overflow-hidden"
      >
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat transition-transform duration-[2s]"
          style={{
            backgroundImage: `url(${project.imageUrl})`,
            transform: getBackgroundTransform(firstSlideInView, 0)
          }}
        >
          <div className="absolute inset-0 bg-black bg-opacity-50" />
        </div>
        
        <div 
          className={`fixed top-[50%] ${getTextPositionClasses()} max-w-2xl transform transition-all duration-[1.2s] ease-out ${
            getSlideTransform(firstSlideInView, 0)
          }`}
          style={{
            opacity: firstSlideInView ? 1 : 0,
            willChange: 'transform, opacity'
          }}
        >
          <div className="bg-black bg-opacity-80 backdrop-blur-sm p-8 md:p-12 rounded-lg shadow-2xl">
            <h3 className="text-4xl md:text-5xl font-bold mb-4 text-white">{project.title}</h3>
            <h4 className="text-xl md:text-2xl mb-6 text-gray-300">{project.location}</h4>
            <p className="text-lg md:text-xl leading-relaxed text-gray-200">{project.description}</p>
          </div>
        </div>
      </section>

      {/* Second Slide - Images */}
      <section
        id={`${project.id}-2`}
        ref={secondSlideRef}
        className="relative h-[200vh] w-full overflow-hidden bg-black"
      >
        <div 
          className={`fixed top-[50%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-full flex flex-col items-center justify-center gap-8 p-12 transform transition-all duration-[1.2s] ease-out ${
            secondSlideInView ? 'translate-y-[-50%] opacity-100' : 'translate-y-[50vh] opacity-0'
          }`}
          style={{ willChange: 'transform, opacity' }}
        >
          <div className="w-full max-w-3xl space-y-8">
            {[project.imageUrl, project.imageUrl2, project.imageUrl3].map((url, index) => (
              <div
                key={index}
                className="w-full h-[50vh] rounded-lg overflow-hidden transform transition-all duration-1000"
                style={{
                  transitionDelay: `${index * 200}ms`,
                  transform: secondSlideInView ? 'translateY(0)' : 'translateY(100px)',
                  opacity: secondSlideInView ? 1 : 0,
                  willChange: 'transform, opacity'
                }}
              >
                <img
                  src={url}
                  alt={`${project.title} - Image ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Third Slide - Video */}
      <section
        id={`${project.id}-3`}
        ref={thirdSlideRef}
        className="relative h-[200vh] w-full overflow-hidden"
      >
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat transition-transform duration-[2s]"
          style={{
            backgroundImage: `url(${project.imageUrl})`,
            transform: thirdSlideInView ? 'scale(1.2)' : 'scale(1.1)',
            willChange: 'transform'
          }}
        >
          <div className="absolute inset-0 bg-black bg-opacity-50" />
        </div>
        
        <div 
          className={`fixed top-[50%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-full p-8 md:p-12 transform transition-all duration-[1.2s] ease-out ${
            thirdSlideInView ? 'translate-y-[-50%] opacity-100' : 'translate-y-[50vh] opacity-0'
          }`}
          style={{ willChange: 'transform, opacity' }}
        >
          <div className="bg-black bg-opacity-80 backdrop-blur-sm p-8 md:p-12 rounded-lg shadow-2xl max-w-4xl mx-auto">
            <div className="aspect-video w-full mb-8 bg-gray-900 rounded-lg overflow-hidden">
              <video
                className="w-full h-full object-cover"
                controls
                poster={project.imageUrl}
              >
                <source src={project.videoUrl} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            </div>
            <button className="bg-white text-black px-8 py-4 rounded-full font-semibold hover:bg-opacity-90 transition-colors text-lg">
              Watch Full Documentary
            </button>
          </div>
        </div>
      </section>

      {/* Project Summary Slide */}
      <section
        ref={summaryRef}
        className="relative h-[100vh] bg-black flex items-center justify-center overflow-hidden"
      >
        <div 
          className={`text-center max-w-4xl px-8 transform transition-all duration-1000 ${
            summaryInView ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'
          }`}
        >
          <h3 className="text-4xl md:text-5xl font-bold text-white mb-6">{project.title}</h3>
          <p className="text-xl text-gray-400 leading-relaxed">
            Experience the rich cultural heritage and traditional craftsmanship that makes {project.location} unique. 
            Join us on this journey of discovery and preservation.
          </p>
        </div>
      </section>

      {/* Final blank strip (only for the last project) */}
      {isLast && (
        <section className="h-[50vh] bg-black" />
      )}
    </>
  );
}