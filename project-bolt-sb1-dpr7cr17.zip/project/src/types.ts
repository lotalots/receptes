export interface Project {
  id: string;
  title: string;
  location: string;
  coordinates: [number, number];
  description: string;
  imageUrl: string;
  imageUrl2: string;
  imageUrl3: string;
  videoUrl: string;
  textPosition: 'left' | 'center' | 'right';
  transitionType: 'vertical' | 'horizontal';
}